"""tfn.data.tokenization
Centralised tokenisation utilities for every text-based dataset loader.

All dataset loaders should import from this module **only** – duplicate
_helpers scattered across loaders are deprecated and will be removed.

The implementation prefers HuggingFace `transformers` tokenisers but
falls back to NLTK or a simple regex when those are unavailable.  This
keeps the pipeline robust on Kaggle kernels where internet access may be
restricted.
"""
from __future__ import annotations

from pathlib import Path
from typing import List, Dict, Optional

import re
from collections import Counter

import torch

# -----------------------------------------------------------------------------
# Optional runtime dependencies ------------------------------------------------
# -----------------------------------------------------------------------------

# Flags for optional deps
_HAVE_TRANSFORMERS = False

try:
    from transformers import AutoTokenizer, BertTokenizer  # type: ignore

    _HAVE_TRANSFORMERS = True
except ImportError:  # pragma: no cover – transformers not installed
    _HAVE_TRANSFORMERS = False

try:
    import nltk  # type: ignore
    from nltk.tokenize import word_tokenize  # type: ignore

    if not Path("~/.nltk_data").expanduser().exists():
        # Download punkt tokenizer silently if it is missing – guards CI
        try:
            nltk.data.find("tokenizers/punkt")
        except LookupError:
            nltk.download("punkt", quiet=True)  # pragma: no cover
    _HAVE_NLTK = True
except ImportError:  # pragma: no cover – NLTK not installed
    _HAVE_NLTK = False

try:
    from datasets import load_dataset  # type: ignore
    _HAVE_DATASETS = True
except ImportError:  # pragma: no cover
    _HAVE_DATASETS = False

# -----------------------------------------------------------------------------
# Public API -------------------------------------------------------------------
# -----------------------------------------------------------------------------

__all__ = [
    "get_tokenizer",
    "tokenize",
    "build_vocab",
    "texts_to_tensor",
    "has_hf",
    "load_hf_dataset",
    "has_nltk",
]


SPECIAL_TOKENS = {
    "<PAD>": 0,
    "<UNK>": 1,
    "[CLS]": 2,
    "[SEP]": 3,
    "[MASK]": 4,
}


# -----------------------------------------------------------------------------
# Tokeniser selection ----------------------------------------------------------
# -----------------------------------------------------------------------------

def get_tokenizer(model_name: str = "distilbert-base-uncased"):
    """Return the best available sub-word tokenizer.

    1.  Try HuggingFace *transformers* (`AutoTokenizer`).
    2.  Fallback to classic `BertTokenizer` if AutoTokenizer download fails.
    3.  If *transformers* is missing, fallback to NLTK (`word_tokenize`).
    4.  Final fallback – whitespace / regex splitter.
    """
    if _HAVE_TRANSFORMERS:
        try:
            return AutoTokenizer.from_pretrained(model_name)
        except Exception:  # pragma: no cover – offline / cache miss
            try:
                return BertTokenizer.from_pretrained("bert-base-uncased")
            except Exception:
                pass  # fallthrough
    # transformers unavailable – NLTK fallback
    if _HAVE_NLTK:
        return None  # signal to downstream that NLTK should be used
    # Final fallback – regex based tokenisation → downstream will handle
    return None


# -----------------------------------------------------------------------------
# Primitive tokenisation wrappers ---------------------------------------------
# -----------------------------------------------------------------------------

def _tokenize_with_transformers(text: str, tokenizer):
    return tokenizer.tokenize(text.lower())


def _tokenize_with_nltk(text: str):
    return word_tokenize(text.lower()) if _HAVE_NLTK else re.findall(r"\b\w+\b", text.lower())


def tokenize(text: str, tokenizer=None):
    """Tokenise *text* into a list of string tokens.

    The strategy:
    • If a *transformers* tokenizer instance is supplied → use it.
    • If `tokenizer is None` but we have an HF tokenizer → not possible; you
      must pass it explicitly so loaders can cache the instance.
    • If `tokenizer is None` fall back to NLTK or regex.
    """
    if tokenizer is not None:
        return _tokenize_with_transformers(text, tokenizer)
    return _tokenize_with_nltk(text)


# -----------------------------------------------------------------------------
# Vocab building ----------------------------------------------------------------
# -----------------------------------------------------------------------------

def build_vocab(texts: List[str], vocab_size: int = 10000, tokenizer=None) -> Dict[str, int]:
    """Create a *word → index* mapping from *texts*.

    The first indices are reserved for `SPECIAL_TOKENS`.
    """
    counter: Counter[str] = Counter()
    for line in texts:
        counter.update(tokenize(line, tokenizer))

    word2idx: Dict[str, int] = dict(SPECIAL_TOKENS)
    for word, _ in counter.most_common(vocab_size - len(SPECIAL_TOKENS)):
        word2idx[word] = len(word2idx)
    return word2idx


# -----------------------------------------------------------------------------
# Text → Tensor helper ---------------------------------------------------------
# -----------------------------------------------------------------------------

def texts_to_tensor(
    texts: List[str],
    word2idx: Dict[str, int],
    *,
    seq_len: int = 128,
    shuffle_tokens: bool = False,
    tokenizer=None,
) -> torch.Tensor:
    """Convert *texts* into an integer tensor `[B, seq_len]` using *word2idx*."""
    tensor_data: List[List[int]] = []
    for text in texts:
        tokens = tokenize(text, tokenizer)
        if shuffle_tokens:
            import random

            random.shuffle(tokens)
        ids = [word2idx.get(tok, word2idx["<UNK>"]) for tok in tokens]

        # Prepend [CLS] if available (keeps compat with BERT-style cls pooling)
        if "[CLS]" in word2idx:
            ids = [word2idx["[CLS]"]] + ids

        # Pad / truncate
        if len(ids) >= seq_len:
            ids = ids[:seq_len]
        else:
            ids += [word2idx["<PAD>"]] * (seq_len - len(ids))
        tensor_data.append(ids)

    return torch.tensor(tensor_data, dtype=torch.long)


# -----------------------------------------------------------------------------
# Optional HuggingFace datasets helpers ---------------------------------------
# -----------------------------------------------------------------------------


def has_hf() -> bool:
    """Return *True* if the `datasets` library is installed."""

    return _HAVE_DATASETS


def load_hf_dataset(*args, **kwargs):  # type: ignore
    """Thin wrapper around `datasets.load_dataset` with runtime import guard."""

    if not _HAVE_DATASETS:
        raise ImportError("HuggingFace `datasets` is not available.")
    from datasets import load_dataset  # local import to keep optional

    return load_dataset(*args, **kwargs)


# -----------------------------------------------------------------------------
# Runtime capability flags -----------------------------------------------------
# -----------------------------------------------------------------------------


def has_nltk() -> bool:
    """Return *True* if NLTK is available."""
    return _HAVE_NLTK 