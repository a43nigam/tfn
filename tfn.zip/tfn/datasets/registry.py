"""
Dataset Registry for TFN Unified Training System

This module provides a centralized registry of all available datasets with their
parameters, task types, and compatibility information.
"""

from typing import Dict, List, Any, Optional, Tuple

# Dataset Registry with all parameters and task types
DATASET_REGISTRY = {
    # ============================================================================
    # CLASSIFICATION DATASETS
    # ============================================================================
    
    'sst2': {
        'task_type': 'classification',
        'num_classes': 2,
        'input_type': 'text',
        'max_seq_len': 128,
        'vocab_size': 10000,
        'description': 'Stanford Sentiment Treebank - binary sentiment classification',
        'loader_function': 'load_sst2',
        'default_params': {
            'seq_len': 128,
            'vocab_size': 10000,
            'val_split': 1000
        }
    },
    
    'mrpc': {
        'task_type': 'classification',
        'num_classes': 2,
        'input_type': 'text',
        'max_seq_len': 128,
        'vocab_size': 10000,
        'description': 'Microsoft Research Paraphrase Corpus - paraphrase detection',
        'loader_function': 'load_mrpc',
        'default_params': {
            'seq_len': 128,
            'vocab_size': 10000,
            'val_split': 500
        }
    },
    
    'qqp': {
        'task_type': 'classification',
        'num_classes': 2,
        'input_type': 'text',
        'max_seq_len': 128,
        'vocab_size': 15000,
        'description': 'Quora Question Pairs - question similarity',
        'loader_function': 'load_qqp',
        'default_params': {
            'seq_len': 128,
            'vocab_size': 15000,
            'val_split': 2000
        }
    },
    
    'qnli': {
        'task_type': 'classification',
        'num_classes': 2,
        'input_type': 'text',
        'max_seq_len': 256,
        'vocab_size': 15000,
        'description': 'Question-answering NLI - question-answering natural language inference',
        'loader_function': 'load_qnli',
        'default_params': {
            'seq_len': 256,
            'vocab_size': 15000,
            'val_split': 1000
        }
    },
    
    'rte': {
        'task_type': 'classification',
        'num_classes': 2,
        'input_type': 'text',
        'max_seq_len': 128,
        'vocab_size': 10000,
        'description': 'Recognizing Textual Entailment - textual entailment',
        'loader_function': 'load_rte',
        'default_params': {
            'seq_len': 128,
            'vocab_size': 10000,
            'val_split': 500
        }
    },
    
    'cola': {
        'task_type': 'classification',
        'num_classes': 2,
        'input_type': 'text',
        'max_seq_len': 128,
        'vocab_size': 10000,
        'description': 'Corpus of Linguistic Acceptability - linguistic acceptability',
        'loader_function': 'load_cola',
        'default_params': {
            'seq_len': 128,
            'vocab_size': 10000,
            'val_split': 500
        }
    },
    
    'wnli': {
        'task_type': 'classification',
        'num_classes': 2,
        'input_type': 'text',
        'max_seq_len': 128,
        'vocab_size': 10000,
        'description': 'Winograd NLI - Winograd natural language inference',
        'loader_function': 'load_wnli',
        'default_params': {
            'seq_len': 128,
            'vocab_size': 10000,
            'val_split': 300
        }
    },
    
    'arxiv': {
        'task_type': 'classification',
        'num_classes': 5,
        'input_type': 'text',
        'max_seq_len': 512,
        'vocab_size': 20000,
        'description': 'Arxiv Papers - scientific paper classification',
        'loader_function': 'load_arxiv',
        'default_params': {
            'seq_len': 512,
            'vocab_size': 20000,
            'val_split': 1000
        }
    },
    
    # === Added generic text classification datasets =========================
    'agnews': {
        'task_type': 'classification',
        'num_classes': 4,
        'input_type': 'text',
        'max_seq_len': 128,
        'vocab_size': 15000,
        'description': 'AG News – 4-way news topic classification',
        'loader_function': 'load_agnews',
        'default_params': {
            'seq_len': 128,
            'vocab_size': 15000,
            'val_split': 2400  # 120k train / 7.6k val by default
        }
    },
    'imdb': {
        'task_type': 'classification',
        'num_classes': 2,
        'input_type': 'text',
        'max_seq_len': 256,
        'vocab_size': 20000,
        'description': 'IMDB – binary sentiment analysis',
        'loader_function': 'load_imdb',
        'default_params': {
            'seq_len': 256,
            'vocab_size': 20000,
            'val_split': 5000
        }
    },
    'yelp_full': {
        'task_type': 'classification',
        'num_classes': 5,
        'input_type': 'text',
        'max_seq_len': 256,
        'vocab_size': 20000,
        'description': 'Yelp Review Full – 5-class sentiment',
        'loader_function': 'load_yelp_full',
        'default_params': {
            'seq_len': 256,
            'vocab_size': 20000,
            'val_split': 6500
        }
    },

    # =========================================================================
    # TIME-SERIES DATASETS
    # =========================================================================

    '_electricity_tmp': {
        'task_type': 'time_series',
        # Core metadata ---------------------------------------------------
        'input_type': 'sequence',
        'num_features': 1,
        'output_dim': 1,      # predict single next value
        'input_dim': 1,       # same as num_features
        'output_len': 1,
        'description': 'Electricity Transformer Temperature forecasting (Kaggle/HF).',
        # Point to the stable wrapper we just added
        'loader_function': 'climate_loader.load_electricity',
        # ---------------- Default CLI params ---------------------------
        'default_params': {
            'seq_len': 168,   # one week of hourly measurements
            'val_split': 1000,
            'step': 1
        }
    },
    
    # =========================================================================
    # REGRESSION DATASETS
    # ============================================================================
    
    'stsb': {
        'task_type': 'regression',
        'output_dim': 1,
        'input_type': 'text',
        'max_seq_len': 128,
        'vocab_size': 10000,
        'description': 'Semantic Textual Similarity Benchmark - semantic similarity regression',
        'loader_function': 'load_stsb',
        'default_params': {
            'seq_len': 128,
            'vocab_size': 10000,
            'val_split': 500
        }
    },
    
    # ============================================================================
    # TIME SERIES DATASETS
    # ============================================================================
    
    'jena': {
        'task_type': 'time_series',
        'output_dim': 1,
        'input_type': 'time_series',
        'max_seq_len': 128,
        'num_features': 1,
        'description': 'Jena Climate - single variable climate forecasting',
        'loader_function': 'load_jena_climate',
        'default_params': {
            'seq_len': 128,
            'step': 1
        }
    },
    
    'jena_multi': {
        'task_type': 'time_series',
        'output_dim': 14,
        'input_type': 'time_series',
        'max_seq_len': 128,
        'num_features': 14,
        'description': 'Jena Climate Multi-variable - multi-variable climate forecasting',
        'loader_function': 'load_jena_climate_multi',
        'default_params': {
            'seq_len': 128,
            'step': 1
        }
    },
    
    # ============================================================================
    # LANGUAGE MODELING DATASETS
    # ============================================================================
    
    'pg19': {
        'task_type': 'language_modeling',
        'vocab_size': 50000,
        'input_type': 'text',
        'max_seq_len': 4096,
        'description': 'PG-19 - long-form language modeling',
        'loader_function': 'create_pg19_dataloader',
        'default_params': {
            'seq_len': 4096,
            'vocab_size': 50000
        }
    },
    
    'long_text': {
        'task_type': 'language_modeling',
        'vocab_size': 30000,
        'input_type': 'text',
        'max_seq_len': 8192,
        'description': 'Long Text - long sequence text classification',
        'loader_function': 'load_long_text',
        'default_params': {
            'seq_len': 8192,
            'vocab_size': 30000
        }
    },
    
    # ============================================================================
    # VISION DATASETS
    # ============================================================================
    
    'cifar10': {
        'task_type': 'vision',
        'num_classes': 10,
        'input_type': 'image',
        'image_size': 32,
        'description': 'CIFAR-10 - image classification',
        'loader_function': 'load_cifar10',
        'default_params': {
            'patch_size': 4,
            'grid_size': 8
        }
    },
    
    # ============================================================================
    # NER DATASETS
    # ============================================================================
    
    'conll2003': {
        'task_type': 'ner',
        'num_tags': 9,
        'input_type': 'text',
        'max_seq_len': 128,
        'vocab_size': 10000,
        'description': 'CoNLL-2003 - Named Entity Recognition',
        'loader_function': 'load_conll2003',
        'default_params': {
            'seq_len': 128,
            'vocab_size': 10000
        }
    }
}

# Task compatibility matrix
TASK_COMPATIBILITY = {
    'classification': {
        'models': ['tfn_classifier', 'enhanced_tfn_classifier', 'transformer_classifier', 
                  'performer_classifier', 'lstm_classifier', 'cnn_classifier'],
        'datasets': ['sst2', 'mrpc', 'qqp', 'qnli', 'rte', 'cola', 'wnli', 'arxiv', 'agnews', 'imdb', 'yelp_full']
    },
    'regression': {
        'models': ['tfn_regressor', 'transformer_regressor', 'performer_regressor', 
                  'lstm_regressor', 'cnn_regressor'],
        'datasets': ['stsb']
    },
    'time_series': {
        'models': ['tfn_timeseries_regressor', 'tfn_multistep_regressor', 'tfn_sequence_regressor',
                  'transformer_regressor', 'performer_regressor', 'lstm_regressor', 'cnn_regressor'],
        'datasets': ['electricity', 'jena', 'jena_multi']
    },
    'language_modeling': {
        'models': ['tfn_language_model', 'enhanced_tfn_language_model', 'transformer_language_model', 
                  'performer_language_model'],
        'datasets': ['pg19', 'long_text']
    },
    'vision': {
        'models': ['tfn_vision'],
        'datasets': ['cifar10']
    },
    'ner': {
        'models': [],  # No NER models implemented yet
        'datasets': ['conll2003']
    }
}

def get_dataset_config(dataset_name: str) -> Dict[str, Any]:
    """Get dataset configuration by name."""
    if dataset_name not in DATASET_REGISTRY:
        raise ValueError(f"Unknown dataset: {dataset_name}. Available datasets: {list(DATASET_REGISTRY.keys())}")
    return DATASET_REGISTRY[dataset_name]

def get_task_compatibility(task: str) -> Dict[str, List[str]]:
    """Get compatible models and datasets for a task."""
    if task not in TASK_COMPATIBILITY:
        raise ValueError(f"Unknown task: {task}. Available tasks: {list(TASK_COMPATIBILITY.keys())}")
    return TASK_COMPATIBILITY[task]

def validate_dataset_task_compatibility(dataset_name: str, task: str) -> bool:
    """Validate that a dataset is compatible with a task."""
    task_config = get_task_compatibility(task)
    return dataset_name in task_config['datasets']

def get_dataset_task_type(dataset_name: str) -> str:
    """Get the task type for a dataset."""
    config = get_dataset_config(dataset_name)
    return config['task_type']

def get_dataset_default_params(dataset_name: str) -> Dict[str, Any]:
    """Get default parameters for a dataset."""
    config = get_dataset_config(dataset_name)
    return config.get('default_params', {})

def get_dataset_loader_function(dataset_name: str) -> str:
    """Get the loader function name for a dataset."""
    config = get_dataset_config(dataset_name)
    return config['loader_function']

def get_dataset_output_dim(dataset_name: str) -> int:
    """Get the output dimension for a dataset."""
    config = get_dataset_config(dataset_name)
    if config['task_type'] == 'classification':
        return config['num_classes']
    elif config['task_type'] == 'regression':
        return config['output_dim']
    elif config['task_type'] == 'time_series':
        return config['output_dim']
    elif config['task_type'] == 'ner':
        return config['num_tags']
    else:
        raise ValueError(f"Unknown task type: {config['task_type']}")

def get_dataset_vocab_size(dataset_name: str) -> Optional[int]:
    """Get the vocabulary size for a dataset (if applicable)."""
    config = get_dataset_config(dataset_name)
    return config.get('vocab_size')

def get_dataset_max_seq_len(dataset_name: str) -> Optional[int]:
    """Get the maximum sequence length for a dataset (if applicable)."""
    config = get_dataset_config(dataset_name)
    return config.get('max_seq_len') 